package main;

import main.AppUI;

public class Main {
    public static void main(String[] args) {
        new AppUI();
    }
}

