/**
 * 
 */
/**
 * 
 */
module LibrarySystem {
	requires java.desktop;
}